return host_work()
