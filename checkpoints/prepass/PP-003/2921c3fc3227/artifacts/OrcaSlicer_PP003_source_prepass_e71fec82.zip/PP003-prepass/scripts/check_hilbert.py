#!/usr/bin/env python3
"""Exact integer transcription of native Hilbert, checked against literal PP002 fixtures.
Not a substitute for linking libslic3r or testing clipping/smoothing/extrusion."""
import argparse,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def point(n):
    digits=(n.bit_length()+1)//2
    state=4 if digits&1 else 0
    ns=[4,0,0,12,0,4,4,8,12,8,8,4,8,12,12,0]
    xs=[0,1,1,0,0,0,1,1,1,0,0,1,1,1,0,0]
    ys=[0,0,1,1,0,1,1,0,1,1,0,0,1,0,0,1]
    x=y=0
    for i in range(digits-1,-1,-1):
        state+=(n>>(i*2))&3;x|=xs[state]<<i;y|=ys[state]<<i;state=ns[state]
    return [x,y]
def generate(a,b,c,d):
    size=2
    while size<max(c+1-a,d+1-b): size*=2
    return [[x+a,y+b] for x,y in (point(i) for i in range(size*size))]
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=ROOT/'results');args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    f=json.loads((ROOT/'fixtures/hilbert_pp002.json').read_text());cases=[]
    for a,b,c,d,res,order in f['cases']:
        expect=[[x+a,y+b] for x,y in f['order_'+str(order)]];actual=generate(a,b,c,d)
        assert actual==expect;cases.append(dict(bounds=[a,b,c,d],resolution=res,points=actual,pass_exact=True))
    for n,ex,ey in [(1,1,0),(3,0,3),(7,7,0)]:
        pts=generate(0,0,n,n);assert len(pts)==(n+1)**2 and pts[-1]==[ex,ey] and pts[0]==[0,0]
        assert len(set(map(tuple,pts)))==len(pts)
        assert all(abs(x-u)+abs(y-v)==1 for (x,y),(u,v) in zip(pts,pts[1:]))
    wrong=list(reversed(generate(0,0,3,3)));assert wrong!=f['order_2']
    result=dict(status='PASS',literal_golden_cases=5,hamiltonian_domains=3,reversal_mutant_rejected=True,scope='Integer generator transcription; no native geometry binary executed',cases=cases)
    (args.out/'hilbert_results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: 5 literal PP-002 golden cases; 3 Hamiltonian domains; reversed-path mutant rejected')
if __name__=='__main__':main()
