#!/usr/bin/env python3
"""Read-only tracked-source inventory. Run on a real checkout at assessed SHA.
Lexical inventory (not a C++ type checker): every switch with direct case ip* labels,
all enum/trait references, missing cases and default presence. No git writes/network.
"""
import argparse,json,re,subprocess
from pathlib import Path
SHA='e71fec82f43285567debc4d2b05d51fb47c0820b'
TOKEN=re.compile(r'//[^\n]*|/\*.*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',re.S)
def clean(s): return TOKEN.sub(lambda m: ''.join('\n' if c=='\n' else ' ' for c in m[0]),s)
def switches(s,patterns):
    c=clean(s);out=[]
    for m in re.finditer(r'\bswitch\s*\([^;{}]*\)\s*\{',c):
        begin=m.end();depth=1;end=begin
        while end<len(c) and depth:
            depth+=(c[end]=='{')-(c[end]=='}');end+=1
        body=c[begin:end-1];depth=0;top=[]
        for ch in body:
            if ch=='{': depth+=1
            top.append(ch if depth==0 else '\n' if ch=='\n' else ' ')
            if ch=='}': depth-=1
        top=''.join(top);cases=re.findall(r'\bcase\s+(?:InfillPattern::)?(ip\w+)\s*:',top)
        if cases: out.append(dict(line=s[:m.start()].count('\n')+1,cases=cases,missing_native=sorted(set(patterns)-set(cases)),has_default=bool(re.search(r'\bdefault\s*:',top))))
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path);p.add_argument('--out',type=Path,required=True);p.add_argument('--self-test',action='store_true');a=p.parse_args()
    if a.self_test:
        sample='// case ipFake:\nswitch(p) {case ipA: break; default: break;} switch(q){case ipB: break;}'
        r=switches(sample,['ipA','ipB']);assert len(r)==2 and r[0]['has_default'] and not r[1]['has_default'] and r[0]['missing_native']==['ipB']
        result=dict(status='PASS',scanner_self_tests=1,full_repository_scan_executed=False)
    else:
        if not a.repo: p.error('--repo is required unless --self-test')
        sha=subprocess.run(['git','-C',str(a.repo),'rev-parse','HEAD'],capture_output=True,text=True,timeout=5,check=True).stdout.strip()
        if sha!=SHA: raise SystemExit('Assessed commit mismatch: '+sha)
        files=subprocess.run(['git','-C',str(a.repo),'ls-files','-z','src'],capture_output=True,timeout=10,check=True).stdout.decode().split('\0')
        config=clean((a.repo/'src/libslic3r/PrintConfig.hpp').read_text())
        enum=re.search(r'enum\s+InfillPattern\s*:\s*int\s*\{(.*?)\}',config,re.S)
        if not enum: raise RuntimeError('enum not found')
        patterns=[v for v in re.findall(r'\bip\w+\b',enum[1]) if v!='ipCount']
        inv=[];refs=[];count=0
        for f in files:
            path=a.repo/f
            if path.suffix not in {'.cpp','.hpp','.h','.cc','.cxx'}:continue
            s=path.read_text(errors='replace');count+=1
            inv.extend(dict(path=f,**x) for x in switches(s,patterns))
            for i,line in enumerate(s.splitlines(),1):
                if re.search(r'\b(?:InfillPattern|ip[A-Z]\w*|use_bridge_flow|is_separable_infill_pattern|is_smoothable_infill_pattern|centered|no_sort|can_reverse|restore_source_path_order)\b',line):
                    refs.append(dict(path=f,line=i,text=line))
        result=dict(status='COMPLETE_LEXICAL_SCAN',full_repository_scan_executed=True,assessed_commit=sha,source_files=count,patterns=patterns,switches=inv,references=refs,limitations='Lexical, not C++ semantic completeness; manually review returned references, casts and generated/preprocessed switches.')
    a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(result,indent=2)+'\n');print(result['status'])
if __name__=='__main__':main()
