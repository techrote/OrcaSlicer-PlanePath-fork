#!/usr/bin/env python3
"""Finite, offline decision-equivalence checks. Not a native geometry test."""
import argparse,copy,csv,io,itertools,json,platform,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def legacy(p, role, center, separated, templ, multiline, density, dont_connect, order, calibration, state):
    # Independent transcription of the assessed callers, not read from candidate traits.
    plane=p in ('ipHilbertCurve','ipArchimedeanChords','ipOctagramSpiral')
    centered=p in ('ipArchimedeanChords','ipOctagramSpiral')
    order_cap=p in ('ipConcentric','ipSpiralInset','ipArchimedeanChords','ipOctagramSpiral')
    separable=p in ('ipRectilinear','ipAlignedRectilinear','ipZigZag','ipCrossZag','ipLockedZag','ipGrid','ipTriangles','ipStars','ipCubic','ipQuarterCubic','ipLateralHoneycomb','ipLateralLattice','ipHilbertCurve','ipArchimedeanChords','ipOctagramSpiral')
    sparse=role=='sparse'; external=role in ('top','bottom')
    actual_m=multiline if sparse else 1
    smooth=p in ('ipHilbertCurve','ipOctagramSpiral','ipLightning','ipHoneycomb','ip3DHoneycomb','ipConcentric','ipCrossHatch') or (p in ('ipGrid','ipTriangles','ipStars','ipCubic') and actual_m>1)
    next_order=order if order_cap and external else state[0]
    next_smooth=0.75 if sparse and smooth else state[1]
    mode=center if external else 'surface'
    bbox=('object' if sparse else {'surface':'snug','model':'object','assembly':'extended'}[mode]) if plane else None
    body=(external and center=='model' and centered) or (not external and separated and (separable or templ))
    chain=None
    if plane:
        if dont_connect or density>0.5:
            chain=('calibration' if next_order=='default' and role=='top' and calibration and p=='ipArchimedeanChords' else 'source_reverse' if next_order=='inward' else 'source' if next_order!='default' else 'chain')
        else: chain='connect'
    base_override=p in ('ipConcentricInternal','ipLockedZag')
    no_sort=(p in ('ipMonotonic','ipMonotonicLine','ipConcentric','ipSpiralInset','ipConcentricInternal')) or (role=='top' and calibration) or next_order!='default'
    reverse=p!='ipGrid' and not(role=='top' and calibration) and next_order=='default'
    return (actual_m,next_order,next_smooth,bbox,body,chain,None if base_override else no_sort,None if base_override else reverse,sparse and plane,role=='bridge')

def candidate(t,role,center,separated,templ,multiline,density,dont_connect,order,calibration,state):
    sparse=role=='sparse'; external=role in ('top','bottom')
    m=multiline if sparse else 1
    # Deliberately retain current conditional assignment / previous state.
    out_order=order if t['surface_fill_order'] and external else state[0]
    sm= t['smoothing']=='Always' or (t['smoothing']=='MultilineOnly' and m>1)
    out_smooth=0.75 if sparse and sm else state[1]
    plane=t['origin']!='NotPlanePath'
    body=external and center=='model' and t['surface_center_controls'] or not external and separated and (t['separable'] or templ)
    bbox=None; chain=None
    if plane:
        bbox='object' if sparse else {'surface':'snug','model':'object','assembly':'extended'}[center if external else 'surface']
        if dont_connect or density>0.5:
            special=t['pattern']=='ipArchimedeanChords' and role=='top' and calibration and out_order=='default'
            chain='calibration' if special else 'source_reverse' if out_order=='inward' else 'source' if out_order=='outward' else 'chain'
        else: chain='connect'
    custom=t['custom_extrusion_override']
    protected=(role=='top' and calibration) or out_order!='default'
    return (m,out_order,out_smooth,bbox,body,chain,None if custom else t['collection_no_sort'] or protected,None if custom else not(t['layer_forbids_reverse'] or protected),plane and sparse,role=='bridge' or t['pattern_bridge_flow'])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=ROOT/'results');a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    rows=json.loads((ROOT/'audit/native_patterns.json').read_text())['rows']
    # Compile standalone extracted source predicates and the proposed C++ table.
    with tempfile.TemporaryDirectory(prefix='pp003-') as temp:
        exe=Path(temp)/'compare'
        cmd=['c++','-std=c++17','-O2','-Wall','-Wextra','-Wpedantic',str(ROOT/'prototype/compare.cpp'),'-o',str(exe)]
        build=subprocess.run(cmd,text=True,capture_output=True,timeout=30)
        (a.out/'compile.log').write_text(build.stdout+build.stderr)
        if build.returncode: raise RuntimeError(build.stderr)
        run=subprocess.run([str(exe)],text=True,capture_output=True,timeout=10,check=True)
        (a.out/'cpp_traits.csv').write_text(run.stdout);(a.out/'cpp_checks.log').write_text(run.stderr)
    cpp=list(csv.reader(io.StringIO(run.stdout)))
    assert len(cpp)==len(rows)==31
    cols=['origin','separable','surface_center_controls','surface_fill_order','self_crossing','collection_no_sort','layer_forbids_reverse','smoothing','sparse_multiline_ui','pattern_bridge_flow','bridge_anchor_policy']
    maps={'origin':{'NotPlanePath':0,'Minimum':1,'Center':2},'smoothing':{'Never':0,'Always':1,'MultilineOnly':2},'bridge_anchor_policy':{'Standard':0,'TurningNative':1}}
    for t,c in zip(rows,cpp):
        assert int(c[0])==t['value']
        for i,k in enumerate(cols,1): assert int(c[i])==(maps[k][t[k]] if k in maps else int(t[k])),(t['pattern'],k)
        assert bool(int(c[12]))==(t['anchor_switch_action']=='generate')
        assert float(c[13])==t['void_area_factor']
    # One-factor coverage of the independent contexts plus cross-products at coupled seams.
    contexts=list(itertools.product(['sparse','top','bottom','solid','bridge'],['surface','model','assembly'],[False,True],[False,True],[1,2,3],[.5,.500001],[False,True],['default','outward','inward'],[False,True],[('default',0.),('inward',.4)]))
    checked=0
    for t in rows:
        for ctx in contexts:
            old=legacy(t['pattern'],*ctx);new=candidate(t,*ctx)
            assert old==new,(t['pattern'],ctx,old,new)
            checked+=1
    mutations=[]
    # Explicit nonuniform native controls: each mutation must produce a counterexample.
    for name,p,k,v in [('hilbert_center','ipHilbertCurve','surface_center_controls',True),('arch_smoothing','ipArchimedeanChords','smoothing','Always'),('grid_reversal','ipGrid','layer_forbids_reverse',False),('solid_bridge_trait','ipHilbertCurve','pattern_bridge_flow',True),('quarter_separable','ipQuarterCubic','separable',False),('forced_order_support','ipSpiralInset','surface_fill_order',False)]:
        row=copy.deepcopy(next(t for t in rows if t['pattern']==p));row[k]=v
        witness=next((ctx for ctx in contexts if legacy(p,*ctx)!=candidate(row,*ctx)),None)
        assert witness is not None,name
        mutations.append(dict(name=name,detected=True,witness=witness))
    # Stateful sequence shows why a fresh-per-surface rewrite is NOT a neutral refactor.
    state=('default',0.);sequence=[]
    for p,role,order in [('ipArchimedeanChords','top','outward'),('ipHilbertCurve','top','default'),('ipHilbertCurve','sparse','default'),('ipHilbertCurve','solid','default')]:
        ctx=(role,'surface',False,False,1,1.,True,order,False,state)
        old=legacy(p,*ctx);new=candidate(next(t for t in rows if t['pattern']==p),*ctx)
        assert old==new
        state=(old[1],old[2]);sequence.append(dict(pattern=p,role=role,result_order=state[0],result_smoothing=state[1]))
    assert sequence[1]['result_order']=='outward' and sequence[-1]['result_smoothing']==.75
    # Invalid enum policy is intentionally DIFFERENT, replacing undefined legacy indexing.
    report=dict(status='PASS',native_patterns=31,cpp_predicate_checks=500,cpp_json_fields_compared=403,context_cases=checked,decision_values_per_case=10,mutations=mutations,stateful_sequence=sequence,invalid_enum_cases=4,scope='Decision extraction/transcription only; no Orca factory, clipping, native test suite or G-code execution',compiler=subprocess.run(['c++','--version'],capture_output=True,text=True,timeout=5).stdout.splitlines()[0],python=platform.python_version(),platform=platform.platform())
    (a.out/'decision_results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['status','native_patterns','cpp_predicate_checks','context_cases','invalid_enum_cases']}))
if __name__=='__main__':main()
