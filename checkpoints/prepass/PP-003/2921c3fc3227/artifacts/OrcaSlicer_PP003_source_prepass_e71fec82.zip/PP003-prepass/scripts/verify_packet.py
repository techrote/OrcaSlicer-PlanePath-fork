#!/usr/bin/env python3
"""Verify every retained packet file against MANIFEST.sha256; reject unlisted files."""
import hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/'MANIFEST.sha256'
expected={}
for line in manifest.read_text().splitlines():
    digest,name=line.split('  ',1)
    if Path(name).is_absolute() or '..' in Path(name).parts: raise SystemExit('Unsafe manifest path')
    expected[name]=digest
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p!=manifest}
if actual!=set(expected): raise SystemExit('Missing/unlisted files: '+str(actual^set(expected)))
for name,digest in expected.items():
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest: raise SystemExit('Hash mismatch: '+name)
print(f'PASS: {len(expected)} SHA-256 file records; no unlisted files (manifest excludes itself).')
