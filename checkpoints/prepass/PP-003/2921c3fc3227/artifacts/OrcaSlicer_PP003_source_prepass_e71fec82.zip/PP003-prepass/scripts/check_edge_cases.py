#!/usr/bin/env python3
"""Frozen boundary examples and policy-coupling checks, no slicing geometry."""
import json,argparse
from pathlib import Path
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=R/'results');a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
rows=json.loads((R/'audit/native_patterns.json').read_text())['rows'];tests=[]
for t in rows:
    for layer in [0,1]:
        for surface_bridge in [False,True]:
            actual=(layer>0 and surface_bridge) or t['pattern_bridge_flow']
            assert actual==(layer>0 and surface_bridge)
            tests.append(dict(kind='bridge_flow',pattern=t['pattern'],layer=layer,surface_bridge=surface_bridge,uses_bridge_flow=actual))
    for spacing in [1,2,3,4,5,400001]:
        actual=max(1,spacing//(4 if t['bridge_anchor_policy']=='TurningNative' else 1))
        expected=max(1,spacing//(4 if t['pattern'] in ['ipHilbertCurve','ipOctagramSpiral'] else 1))
        assert actual==expected
        tests.append(dict(kind='scan_spacing',pattern=t['pattern'],physical_spacing=spacing,scan_spacing=actual))
# Do not merge kernel direction semantics: Concentric default inward, SpiralInset default outward.
orders=[]
for o in ['default','outward','inward']:
    concentric_reverse=(o=='outward')
    spiral_reverse=(o!='inward')
    orders.append(dict(order=o,concentric_classic_reverse_loop_order=concentric_reverse,spiral_inset_reverse_paths_and_list=spiral_reverse,concentric_arachne_force_depth_sort=o!='default'))
assert orders[0]['concentric_classic_reverse_loop_order']!=orders[0]['spiral_inset_reverse_paths_and_list']
report=dict(status='PASS',bridge_boundary_cases=len(tests),order_kernel_cases=orders,tests=tests,scope='Transcribed decisions; not native extrusion execution')
(a.out/'edge_results.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS:',len(tests),'bridge boundary decisions; 3 native order-kernel distinctions')
