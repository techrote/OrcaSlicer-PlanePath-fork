# PP-003 audit packet

Start with **HANDOFF.md**. Detailed findings and the complete readable matrix are in **audit/AUDIT.md**. The machine-readable CSV and JSON contain all 31 current native patterns; caller conditions, exceptions, source provenance and switch coverage are separate files so a capability cannot be mistaken for an effective-context decision.

The tested proposal is **prototype/FillPatternTraits.hpp**, with independently transcribed native predicates in **fixtures/legacy_predicates.hpp**. No production refactor patch is included. The exact intended production file sequence is **audit/GEOMETRY_AND_REFACTOR.md**.

Run `python3 scripts/verify_packet.py` before use. Run `python3 scripts/run_all.py --out /tmp/pp003-results` to reproduce the probes without altering the retained results. A C++17 `c++` compiler is needed. The compiler emits two intentional warnings from the legacy anchor switch: missing QuarterCubic and CrossHatch cases. They are audit evidence, not a failed build.

All retained files other than MANIFEST.sha256 are hashed in that manifest. The archive is separately SHA-256-hashed after creation; its external verification receipt records CRC/inventory/hash checks and an extracted-packet rerun. The ZIP cannot contain its own final SHA-256 hash. Reported original Git blob identities are distinct from packet SHA-256 integrity checks.

No remote writes were made. Actual native Orca tests, geometry clipping/slicing and a full-repository scan were not run; those limits are explicit in the handoff and evidence records.
