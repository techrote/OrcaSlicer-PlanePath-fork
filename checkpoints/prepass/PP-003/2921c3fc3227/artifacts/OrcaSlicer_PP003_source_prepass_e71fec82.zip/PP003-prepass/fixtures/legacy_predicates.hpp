#pragma once
// Source extraction/transcription from the assessed commit. No geometry dependency.
// The enum and two switch bodies reproduce PrintConfig.hpp. Additional predicates
// reproduce caller expressions. This is NOT a build of Orca's Fill factory.
namespace legacy {
enum InfillPattern : int {
    ipMonotonic, ipMonotonicLine,
    ipRectilinear, ipAlignedRectilinear, ipZigZag, ipCrossZag, ipLockedZag,
    ipLine, ipGrid,
    ipTriangles, ipStars,
    ipCubic, ipAdaptiveCubic, ipQuarterCubic, ipSupportCubic, ipLightning,
    ipHoneycomb, ip3DHoneycomb, ipLateralHoneycomb, ipLateralLattice,
    ipCrossHatch, ipTpmsD, ipTpmsFK, ipGyroid,
    ipConcentric, ipSpiralInset, ipHilbertCurve, ipArchimedeanChords, ipOctagramSpiral,
    ipSupportBase, ipConcentricInternal,
    ipCount,
};
inline bool is_separable_infill_pattern(InfillPattern pattern) {
    switch (pattern) {
    case ipRectilinear: case ipAlignedRectilinear: case ipZigZag:
    case ipCrossZag: case ipLockedZag: case ipGrid: case ipTriangles:
    case ipStars: case ipCubic: case ipQuarterCubic: case ipLateralHoneycomb:
    case ipLateralLattice: case ipHilbertCurve: case ipArchimedeanChords:
    case ipOctagramSpiral: return true;
    default: return false;
    }
}
inline bool is_smoothable_infill_pattern(InfillPattern pattern, int multiline=1) {
    switch(pattern) {
    case ipHilbertCurve: case ipOctagramSpiral: case ipLightning:
    case ipHoneycomb: case ip3DHoneycomb: case ipConcentric: case ipCrossHatch:
        return true;
    case ipGrid: case ipTriangles: case ipStars: case ipCubic:
        return multiline > 1;
    default: return false;
    }
}
inline bool center_controls(InfillPattern p) {
    return p == ipArchimedeanChords || p == ipOctagramSpiral;
}
inline bool surface_order(InfillPattern p) {
    return p == ipConcentric || p == ipSpiralInset || p == ipArchimedeanChords || p == ipOctagramSpiral;
}
inline bool multiline_ui(InfillPattern p) {
    return p == ipGyroid || p == ipGrid || p == ipRectilinear || p == ipTpmsD || p == ipTpmsFK ||
        p == ipCrossHatch || p == ipHoneycomb || p == ipLateralLattice || p == ipLateralHoneycomb ||
        p == ipConcentric || p == ipCubic || p == ipStars || p == ipAlignedRectilinear ||
        p == ipLightning || p == ip3DHoneycomb || p == ipAdaptiveCubic || p == ipSupportCubic ||
        p == ipTriangles || p == ipQuarterCubic || p == ipArchimedeanChords || p == ipHilbertCurve || p == ipOctagramSpiral;
}
inline bool turning(InfillPattern p) { return p==ipHilbertCurve || p==ipOctagramSpiral; }
// Resolved inherited virtual results, audited against all 31 factory targets.
inline bool declared_self_crossing(InfillPattern p) {
    return p==ipGrid || p==ipTriangles || p==ipStars || p==ipCubic || p==ipAdaptiveCubic || p==ipSupportCubic;
}
inline bool declared_no_sort(InfillPattern p) {
    return p==ipMonotonic || p==ipMonotonicLine || p==ipConcentric || p==ipSpiralInset || p==ipConcentricInternal;
}
inline bool anchor_helper(InfillPattern pattern) {
    switch(pattern) {
    case ipCount: return false;
    case ipSupportBase: return false;
    case ipConcentricInternal: return false;
    case ipLightning: case ipAdaptiveCubic: case ipSupportCubic: case ipRectilinear:
    case ipMonotonic: case ipMonotonicLine: case ipAlignedRectilinear: case ipGrid:
    case ipLateralLattice: case ipTriangles: case ipStars: case ipCubic: case ipLine:
    case ipConcentric: case ipSpiralInset: case ipHoneycomb: case ipLateralHoneycomb:
    case ip3DHoneycomb: case ipGyroid: case ipTpmsD: case ipTpmsFK: case ipHilbertCurve:
    case ipArchimedeanChords: case ipOctagramSpiral: case ipZigZag: case ipCrossZag:
    case ipLockedZag: break;
    }
    return true; // QuarterCubic, CrossHatch and any unlisted sentinel reach generation.
}
inline double void_coefficient(InfillPattern pattern) {
    switch(pattern) {
    case ipConcentric: case ipSpiralInset: case ipRectilinear: case ipLine: case ipGyroid:
    case ipTpmsD: case ipTpmsFK: case ipAlignedRectilinear: case ipOctagramSpiral:
    case ipHilbertCurve: case ipLateralHoneycomb: case ip3DHoneycomb: case ipArchimedeanChords: return 1.;
    case ipGrid: case ipLateralLattice: case ipHoneycomb: case ipLightning: return 4.;
    case ipCubic: case ipAdaptiveCubic: case ipTriangles: case ipStars: case ipSupportCubic: return 4.5;
    default: return 1.;
    }
}
} // namespace legacy
